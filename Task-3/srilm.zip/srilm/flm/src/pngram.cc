/*
 * pngram --
 *	Create and manipulate product ngram (and related) models
 *	(now subsumed by ngram(1)).
 */

#ifndef lint
static char pngram_Copyright[] = "Copyright (c) 2003 SRI International.  All Rights Reserved.";
static char pngram_RcsId[] = "@(#)$Header: /home/srilm/CVS/srilm/flm/src/pngram.cc,v 1.6 2003/11/15 16:58:21 stolcke Exp $";
#endif

#include "../../lm/src/ngram.cc"

